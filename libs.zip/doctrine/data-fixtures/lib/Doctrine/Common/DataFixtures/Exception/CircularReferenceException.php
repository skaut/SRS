<?php

namespace Doctrine\Common\DataFixtures\Exception;

use Doctrine\Common\CommonException;

class CircularReferenceException extends CommonException
{
}
