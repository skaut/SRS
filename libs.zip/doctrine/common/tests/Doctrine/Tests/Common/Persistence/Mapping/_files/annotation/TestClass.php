<?php

namespace Doctrine;

/**
 * @Doctrine\Entity
 */
class TestClass
{
}

/**
 * @Annotation
 */
class Entity
{
}
